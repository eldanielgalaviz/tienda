"use client"

import type React from "react"

import { useState } from "react"
import { Link } from "react-router-dom"
import { Heart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useCart } from "@/hooks/use-cart"
import { useToast } from "@/components/ui/use-toast"
import type { Product } from "@/types"

interface ProductCardProps {
  product: Product
}

const ProductCard = ({ product }: ProductCardProps) => {
  const [isHovered, setIsHovered] = useState(false)
  const { addItem } = useCart()
  const { toast } = useToast()

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()

    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.images[0],
      quantity: 1,
      variant: product.variants[0].id,
    })

    toast({
      title: "Producto añadido",
      description: `${product.name} ha sido añadido al carrito.`,
    })
  }

  const handleAddToWishlist = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()

    toast({
      title: "Añadido a favoritos",
      description: `${product.name} ha sido añadido a tu lista de deseos.`,
    })
  }

  return (
    <Link
      to={`/producto/${product.id}`}
      className="group block"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative overflow-hidden rounded-md mb-3">
        <img
          src={product.images[0] || "/placeholder.svg"}
          alt={product.name}
          className="w-full aspect-square object-cover transition-transform duration-500 group-hover:scale-105"
        />

        {/* Product tags */}
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {product.tags.includes("nuevo") && (
            <span className="bg-black text-white text-xs px-2 py-1 rounded">NUEVO</span>
          )}
          {product.tags.includes("oferta") && (
            <span className="bg-red-600 text-white text-xs px-2 py-1 rounded">OFERTA</span>
          )}
        </div>

        {/* Quick actions */}
        <div
          className={`absolute bottom-0 left-0 right-0 bg-white/90 p-2 flex justify-between transition-all duration-300 ${
            isHovered ? "translate-y-0 opacity-100" : "translate-y-full opacity-0"
          }`}
        >
          <Button variant="outline" size="sm" className="flex-1 mr-1" onClick={handleAddToCart}>
            Añadir al carrito
          </Button>
          <Button variant="outline" size="icon" className="ml-1" onClick={handleAddToWishlist}>
            <Heart className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <h3 className="font-medium text-lg">{product.name}</h3>
      <p className="font-bold">${product.price.toLocaleString("es-MX")}</p>
    </Link>
  )
}

export default ProductCard

