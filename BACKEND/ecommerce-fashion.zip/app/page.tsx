"use client"

import ProductCard from "../src/components/product/ProductCard"

export default function SyntheticV0PageForDeployment() {
  return <ProductCard />
}